from .convnet import convnet4
from .resnet_ssl import resnet12_ssl

#from .Vit12 import vit12

model_pool = [
    'convnet4',
    'resnet12_ssl',
]

model_dict = {
    'convnet4': convnet4,
    'resnet12_ssl': resnet12_ssl,
}
