"""
the general training framework
"""

from __future__ import print_function

import os
import argparse
import socket
import time
import sys
from tqdm import tqdm
import mkl

import torch
import torch.optim as optim
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.utils.data import DataLoader
import torch.nn.functional as F
from torch.optim.lr_scheduler import MultiStepLR
from models import model_pool
from models.util import create_model, get_teacher_name

from distill.util import Embed
from distill.criterion import DistillKL, NCELoss, Attention, HintLoss


from dataset.mini_imagenet import ImageNet, MetaImageNet
from dataset.tiered_imagenet import TieredImageNet, MetaTieredImageNet
from dataset.cifar import CIFAR100, MetaCIFAR100
from dataset.transform_cfg import transforms_options, transforms_list

from util import adjust_learning_rate, accuracy, AverageMeter
from eval.meta_eval import meta_test, meta_test_tune
from eval.cls_eval import validate

from models.resnet import resnet12
import numpy as np
from util import Logger

from dataloader import get_dataloaders
import copy

"""Few-shot Classification Model Compression via School Learning
    """

os.environ["CUDA_VISIBLE_DEVICES"] = '0'





def parse_option():
    parser = argparse.ArgumentParser('argument for training')

    parser.add_argument('--eval_freq', type=int, default=10, help='meta-eval frequency')
    parser.add_argument('--print_freq', type=int, default=100, help='print frequency')
    parser.add_argument('--tb_freq', type=int, default=500, help='tb frequency')
    parser.add_argument('--save_freq', type=int, default=10, help='save frequency')
    parser.add_argument('--batch_size', type=int, default=64, help='batch_size')
    parser.add_argument('--num_workers', type=int, default=8, help='num of workers to use')
    parser.add_argument('--epochs', type=int, default=100, help='number of training epochs')

    # optimization
    parser.add_argument('--learning_rate', type=float, default=0.05, help='learning rate')
    parser.add_argument('--lr_decay_epochs', type=str, default='60,80', help='where to decay lr, can be a list')
    parser.add_argument('--lr_decay_rate', type=float, default=0.1, help='decay rate for learning rate')
    parser.add_argument('--weight_decay', type=float, default=5e-4, help='weight decay')
    parser.add_argument('--momentum', type=float, default=0.9, help='momentum')

    # dataset and model
    parser.add_argument('--model_names', type=str, nargs='+', default=['convnet4', 'convnet4', 'convnet4'])
    parser.add_argument('--model_s', type=str, default='convnet4', choices=model_pool)
    parser.add_argument('--model_t', type=str, default='resnet12_ssl', choices=model_pool)
    parser.add_argument('--dataset', type=str, default='miniImageNet', choices=['miniImageNet', 'CIFAR-FS', 'FC100','CUB_200_2011'])
    parser.add_argument('--simclr', type=bool, default=False, help='use simple contrastive learning representation')
    parser.add_argument('--ssl', type=bool, default=True, help='use self supervised learning')
    parser.add_argument('--transform', type=str, default='A', choices=transforms_list)

    # path to pretrained model
    parser.add_argument('--path_s', type=str,default="/save/", help='student model path')
    parser.add_argument('--path_t', type=str,default="/save/", help='teacher model path')

    # distillation
    parser.add_argument('--distill', type=str, default='kd', choices=['kd', 'contrast', 'hint', 'attention'])
    parser.add_argument('--trial', type=str, default='1', help='trial id')

    parser.add_argument('--alpha', type=float, default=1, help='weight balance for KD')
    parser.add_argument('--beta', type=float, default=0.1, help='weight balance for KD')

    parser.add_argument('--n_cluster', default=5, type=int, help='number of cluster')

    # KL distillation
    parser.add_argument('--kd_T', type=float, default=16, help='temperature for KD distillation')

    # cosine annealing
    parser.add_argument('--cosine', action='store_true', help='using cosine annealing')

    # specify folder
    parser.add_argument('--model_path', type=str, default='/save/distillation/', help='path to save model')
    parser.add_argument('--data_root', type=str, default='/Dataset/',help='path to data root')

    # setting for meta-learning
    parser.add_argument('--n_test_runs', type=int, default=600, metavar='N',
                        help='Number of test runs')
    parser.add_argument('--n_ways', type=int, default=5, metavar='N',
                        help='Number of classes for doing each classification run')
    parser.add_argument('--n_shots', type=int, default=1, metavar='N',
                        help='Number of shots in test')
    parser.add_argument('--n_queries', type=int, default=15, metavar='N',
                        help='Number of query in test')
    parser.add_argument('--n_aug_support_samples', default=5, type=int,
                        help='The number of augmented samples for each meta test sample')
    parser.add_argument('--test_batch_size', type=int, default=1, metavar='test_batch_size',
                        help='Size of test batch)')

    opt = parser.parse_args()

    if opt.dataset == 'CIFAR-FS' or opt.dataset == 'FC100':
        opt.transform = 'D'


    opt.use_trainval = False

    if 'trainval' in opt.path_t:
        opt.use_trainval = True
    else:
        opt.use_trainval = False

    if opt.use_trainval:
        opt.trial = opt.trial + '_trainval'

    # set the path according to the environment

    opt.data_root = '{}/{}'.format(opt.data_root, opt.dataset)
    opt.data_aug = True
    iterations = opt.lr_decay_epochs.split(',')
    opt.lr_decay_epochs = list([])
    for it in iterations:
        opt.lr_decay_epochs.append(int(it))

    opt.model_name = 'S:{}_T:{}'.format(opt.model_s, opt.model_t)


    opt.save_folder = os.path.join(opt.model_path, opt.model_name)
    if not os.path.isdir(opt.save_folder):
        os.makedirs(opt.save_folder)


    return opt


def load_teacher(model_path, model_name, n_cls, dataset='miniImageNet'):
    """load the  model"""
    print('==> loading model {}'.format(model_name))
    model = create_model(model_name, n_cls, dataset)
    model.load_state_dict(torch.load(model_path)['model'])
    print('==> done')
    return model


def main():
    best_acc = 0

    opt = parse_option()

    # dataloader
    train_loader, val_loader, meta_testloader, meta_valloader, n_cls = get_dataloaders(opt)
    model_t = (load_teacher(opt.path_t, opt.model_t, n_cls, opt.dataset))
    nets, optimizers, schs = [], [], []
    for name in opt.model_names:
        model = load_teacher(opt.path_s, opt.model_s, n_cls, opt.dataset)
        optimizer = optim.SGD(model.parameters(), lr=opt.learning_rate, momentum=opt.momentum, weight_decay=opt.weight_decay)
        scheduler = MultiStepLR(optimizer, opt.lr_decay_epochs)
        nets.append(model)
        optimizers.append(optimizer)
        schs.append(scheduler)

    criterion_cls = nn.CrossEntropyLoss()
    criterion_div = DistillKL(opt.kd_T)
    criterion_kd = nn.MSELoss()
    if torch.cuda.is_available():
        for net in nets:
            net.cuda()
        model_t.cuda()
        criterion_cls = criterion_cls.cuda()
        criterion_div = criterion_div.cuda()
        criterion_kd = criterion_kd.cuda()
        cudnn.benchmark = True


    meta_val_acc = 0
    # routine: supervised model distillation
    for epoch in range(1, opt.epochs + 1):
        for net_idx, optimizer in enumerate(optimizers):
            adjust_learning_rate(epoch, opt, optimizer)
        print("==> training...")

        time1 = time.time()
        totalloss = train(epoch, train_loader, nets, model_t, optimizers, criterion_cls, criterion_div, criterion_kd, opt)
        time2 = time.time()
        print('epoch {}, total time {:.2f}'.format(epoch, time2 - time1))

        start = time.time()
        meta_test_acc, meta_test_std = meta_test(nets[-1], meta_testloader, use_logit=True)
        test_time = time.time() - start
        print('Meta Test Acc: {:.4f}, Meta Test std: {:.4f}, Time: {:.1f}'.format(meta_test_acc, meta_test_std,
                                                                                  test_time))

        # regular saving
        if epoch % opt.save_freq == 0 or epoch == opt.epochs:
            print('==> Saving...')
            state = {
                'epoch': epoch,
                'model': nets[-1].state_dict(),
            }
            save_file = os.path.join(opt.save_folder, 'maxacc' + '.pth')
            torch.save(state, save_file)


def train(epoch, train_loader, nets, model_t,optimizers, criterion_cls, criterion_div, criterion_kd, opt):
    for net in nets:
        net.train()
    model_t.eval()
    top1 = AverageMeter()
    top5 = AverageMeter()
    lossl = AverageMeter()
    with tqdm(train_loader, total=len(train_loader)) as pbar:
        for idx, data in enumerate(pbar):

            inputs, targets, _ = data

            inputs = inputs.float()
            if torch.cuda.is_available():
                inputs = inputs.cuda()
                targets = targets.cuda()

            batch_size = inputs.size()[0]
            x = inputs
            inputs_all = x
            with torch.no_grad():
                feat_t_all, (logit_t, rot_t) = model_t(inputs_all, rot=True)
            # ===================forward=====================
            out_list = []
            feat_list= []
            for net_idx, net in enumerate(nets):
                feat_s_all,(logit_s_all,_)  = net(inputs_all, rot=True)# [b, num_classes]
                out_list.append(logit_s_all)
                feat_list.append(feat_s_all[-1])
            for net_idx, net in enumerate(nets):
                if net_idx != len(nets):
                   ce_loss = criterion_cls(out_list[net_idx], targets)
                   kd_loss = criterion_div(out_list[net_idx], logit_t)
                   fe_loss = criterion_kd(feat_list[net_idx],feat_t_all[-1].detach())
                   KLD_loss = criterion_div(out_list[net_idx], out_list[-1].detach())
                else:
                   ce_loss = criterion_cls(out_list[-1], targets)
                   kd_loss = criterion_div(out_list[-1], logit_t)
                   fe_loss = criterion_kd(feat_list[-1], feat_t_all[-1])
                   KLD_loss = 0
                   for l in range(len(nets) - 1):
                        KLD_loss += criterion_div(out_list[-1], out_list[l].detach())
                loss = ce_loss + opt.alpha * kd_loss + opt.alpha*fe_loss + opt.beta * KLD_loss
                #loss = ce_loss  + 0.3 * KLD_loss
                optimizers[net_idx].zero_grad()
                loss.backward()
                optimizers[net_idx].step()
            acc1, acc5 = accuracy(out_list[-1], targets, topk=(1, 5))
            top1.update(acc1[0], inputs.size(0))
            top5.update(acc5[0], inputs.size(0))

        print(' Train Acc@1 {top1.avg:.3f} Acc@5 {top5.avg:.3f}'
                  .format(top1=top1, top5=top5))

        return  loss

if __name__ == '__main__':
    main()
