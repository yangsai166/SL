# Few-shot Classification Model Compression via School Learning

This repository contains the code for our paper '[Few-shot Classification Model Compression via School Learning]'

## Environment
This code requires the following:
* matplotlib==3.2.1
* numpy==1.18.4
* Pillow==7.1.2
* scikit_learn==0.23.1
* scipy==1.4.1
* torch==1.5.0
* torchvision==0.6.0
* tqdm==4.46.0

## Download Data
The data we used here is preprocessed by the repo of [MetaOptNet](https://github.com/kjunelee/MetaOptNet), Please find the renamed versions of the files in below link by [RFS](https://github.com/WangYueFt/rfs).

[[DropBox Data Packages Link]](https://www.dropbox.com/sh/6yd1ygtyc3yd981/AABVeEqzC08YQv4UZk7lNHvya?dl=0)
## Pre-training
After preparing the training data in ```data/``` directory, use 
```
python train_Teacher.py
```
to start the pre-training of the teacher network and student network.
## Training
After preparing the training data in ```data/``` directory, use 
```
python train.py
```
to start the training, Use the ```model_names``` argument to choose the type of student network

## Testing

After preparing the testing data in ```test/``` directory, place the mode checkpoint file in the ```/save/distillation/``` directory. 
```
python test.py 
```

## Contact
Should you have any question, please contact yangsai@ntu.edu.cn

**Acknowledgment:** This code is based on the [SKD](https://github.com/brjathu/SKD) and [MDistiller](https://github.com/megvii-research/mdistiller) .
) 

