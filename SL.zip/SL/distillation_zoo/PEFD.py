import torch
import torch.nn as nn
import torch.nn.functional as F
"""Improved Feature Distillation via Projector Ensemble(NIPS 2022)
code:https://github.com/chenyd7/PEFD.
"""
class PEFD(nn.Module):
    """Improved Feature Distillation via Projector Ensemble,NIPS 2022"""
    def __init__(self):
        super(PEFD, self).__init__()

    def forward(self, feat_s, feat_t):
        _, Cs_h = feat_s[-1].shape
        _, Ct_h = feat_t[-1].shape
        f_t = feat_t[-1]
        relu = torch.nn.ReLU()
        reg1 = nn.Linear(Cs_h,Ct_h).cuda()
        reg2 = nn.Linear(Cs_h, Ct_h).cuda()
        reg3 = nn.Linear(Cs_h, Ct_h).cuda()
        # linear Regress
        f_s1 = feat_s[-1]
        f_s1 = reg1(f_s1)
        f_s1 = relu(f_s1)
        f_s2 = feat_s[-1]
        f_s2 = reg2(f_s2)
        f_s2 = relu(f_s2)
        f_s3 = feat_s[-1]
        f_s3 = reg3(f_s3)
        f_s3 = relu(f_s3)
        f_s = (f_s1 + f_s2 + f_s3) / 3
        bsz = f_s.shape[0]
        bdm = f_s.shape[1]

        # inner product (normalize first and inner product)
        normft = f_t.pow(2).sum(1, keepdim=True).pow(1. / 2)
        outft = f_t.div(normft)
        normfs = f_s.pow(2).sum(1, keepdim=True).pow(1. / 2)
        outfs = f_s.div(normfs)

        cos_theta = (outft * outfs).sum(1, keepdim=True)
        G_diff = 1 - cos_theta
        loss_kd = (G_diff).sum() / bsz
        return loss_kd
