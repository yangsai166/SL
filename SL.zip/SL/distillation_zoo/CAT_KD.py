import torch
import torch.nn as nn
import torch.nn.functional as F
from ._base import Distiller
"""Class Attention Transfer Based Knowledge Distillation, CVPR 2023
   code  https://github.com/GzyAftermath/CAT-KD.
"""
class CAT_KD(Distiller):
    """Class Attention Transfer Based Knowledge Distillation, CVPR 2023"""
    def __init__(self,student,teacher):
        super(CAT_KD, self).__init__(student,teacher)
        self.ce_loss_weight = 1.0
        self.CAT_loss_weight = 400.0
        self.onlyCAT = False
        self.CAM_RESOLUTION = 2
        self.relu = nn.ReLU()
        
        self.IF_NORMALIZE = True
        self.IF_BINARIZE = False
        
        self.IF_OnlyTransferPartialCAMs = False
        self.CAMs_Nums = 100
        # 0: select CAMs with top x predicted classes
        # 1: select CAMs with the lowest x predicted classes
        self.Strategy = 0
        
    def forward_train(self, logits_student, feature_student,logits_teacher,feature_teacher):

        tea = feature_teacher
        stu = feature_student
                        
        # perform binarization
        if self.IF_BINARIZE:
            n,c,h,w = tea.shape
            threshold = torch.norm(tea, dim=(2,3), keepdim=True, p=1)/(h*w)
            tea =tea - threshold
            tea = self.relu(tea).bool() * torch.ones_like(tea)
        
        
        # only transfer CAMs of certain classes
        if self.IF_OnlyTransferPartialCAMs:
            n,c,w,h = tea.shape
            with torch.no_grad():
                if self.Strategy==0:
                    l = torch.sort(logits_teacher, descending=True)[0][:, self.CAMs_Nums-1].view(n,1)
                    mask = self.relu(logits_teacher-l).bool()
                    mask = mask.unsqueeze(-1).reshape(n,c,1,1)
                elif self.Strategy==1:
                    l = torch.sort(logits_teacher, descending=True)[0][:, 99-self.CAMs_Nums].view(n,1)
                    mask = self.relu(logits_teacher-l).bool()
                    mask = ~mask.unsqueeze(-1).reshape(n,c,1,1)
            tea,stu = _mask(tea,stu,mask)

        loss_feat = self.CAT_loss_weight * CAT_loss(
            stu, tea, self.CAM_RESOLUTION, self.IF_NORMALIZE
        )

        return loss_feat


def _Normalize(feat,IF_NORMALIZE):
    if IF_NORMALIZE:
        feat = F.normalize(feat,dim=(2,3))
    return feat


def conv1x1(in_channels, out_channels, stride=1):
    return nn.Conv2d(
        in_channels, out_channels,
        kernel_size=1, padding=0,
        bias=False, stride=stride)
def CAT_loss(CAM_Student, CAM_Teacher, CAM_RESOLUTION, IF_NORMALIZE):
    projector=nn.Sequential(
        conv1x1(256, 320),
        nn.ReLU(),
        conv1x1(320, 320),
        nn.ReLU(),
        conv1x1(320, 640),
    ).cuda()
    CAM_Student=projector(CAM_Student)

    CAM_Student = F.adaptive_avg_pool2d(CAM_Student, (CAM_RESOLUTION, CAM_RESOLUTION))

    CAM_Teacher = F.adaptive_avg_pool2d(CAM_Teacher, (CAM_RESOLUTION, CAM_RESOLUTION))

    loss = F.mse_loss(_Normalize(CAM_Student, IF_NORMALIZE), _Normalize(CAM_Teacher, IF_NORMALIZE))
    return loss
    

def _mask(tea,stu,mask):
    n,c,w,h = tea.shape
    mid = torch.ones(n,c,w,h).cuda()
    mask_temp = mask.view(n,c,1,1)*mid.bool()
    t=torch.masked_select(tea, mask_temp)
    
    if (len(t))%(n*w*h)!=0:
        return tea, stu

    n,c,w_stu,h_stu = stu.shape
    mid = torch.ones(n,c,w_stu,h_stu).cuda()
    mask = mask.view(n,c,1,1)*mid.bool()
    stu=torch.masked_select(stu, mask)
    
    return t.view(n,-1,w,h), stu.view(n,-1,w_stu,h_stu)