from __future__ import print_function

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
#from KD import DistillKL
"""Shadow Knowledge Distillation: Bridging Offline and Online Knowledge Transfer,NIPS 2022
   code https://lilujunai.github.io/SHAKE"""
class DistillKL(nn.Module):
    """Distilling the Knowledge in a Neural Network"""
    def __init__(self, T):
        super(DistillKL, self).__init__()
        self.T = T

    def forward(self, y_s, y_t):
        p_s = F.log_softmax(y_s/self.T, dim=1)
        p_t = F.softmax(y_t/self.T, dim=1)
        loss = F.kl_div(p_s, p_t, size_average=False) * (self.T**2) / y_s.shape[0]
        return loss

def conv3x3(in_planes, out_planes, stride=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=False)


def conv1x1(in_planes, out_planes, stride=1):
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)


def conv_bn(inp, oup, stride):
    return nn.Sequential(
        # nn.Conv2d(inp, oup, 1, 1, 0, bias=False),
        nn.Conv2d(inp, oup, 3, stride, 1, bias=False),
        nn.BatchNorm2d(oup),
        nn.ReLU(inplace=True),

    )


def conv_1x1_bn(num_input_channels, num_mid_channel):
    return nn.Sequential(
        conv1x1(num_input_channels, num_mid_channel),
        nn.BatchNorm2d(num_mid_channel),
        nn.ReLU(inplace=True),
        # conv3x3(num_mid_channel, num_mid_channel),
        # nn.BatchNorm2d(num_mid_channel),
        # nn.ReLU(inplace=True),
        # conv1x1(num_mid_channel, num_mid_channel),
    )


class Shake(nn.Module):
    """Convolutional regression for FitNet (feature-map layer)"""

    def __init__(self, feat_t):
        super(Shake, self).__init__()

        self.fuse1 = conv_bn(feat_t[1].shape[1], feat_t[2].shape[1], 2)
        self.fuse2 = conv_1x1_bn(feat_t[2].shape[1], feat_t[2].shape[1])
        self.fuse3 = conv_bn(feat_t[2].shape[1], feat_t[3].shape[1], 2)
        self.fuse4 = conv_1x1_bn(feat_t[3].shape[1], feat_t[3].shape[1])
        self.fuse5 = conv_bn(feat_t[3].shape[1], feat_t[3].shape[1], 1)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        self.fc = nn.Linear(feat_t[3].shape[1], 100)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, f, weight, bias):
        x = self.fuse5(self.fuse3(self.fuse1(f[0]) + self.fuse2(f[1])) + self.fuse4(f[2]))
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = nn.functional.linear(x, weight, bias)
        # x = self.fc(x)
        return x
class ShadowKD(nn.Module):
    """Shadow Knowledge Distillation: Bridging Offline and Online Knowledge Transfer,NIPS 2022"""
    def __init__(self):
        super(ShadowKD, self).__init__()
        self.shake = Shake()
        self.crit1 = nn.CrossEntropyLoss()
        self.crit2 = DistillKL(4)
        self.crit3 = nn.MSELoss()
    def forward(self, feat_s, feat_t, logit_s, logit_t, label, weightt, biast):
        pred_feat_s = self.shake(feat_t[1:-1], weightt.detach(), biast.detach())
        logit_s = F.layer_norm(logit_s, torch.Size((100,)), None, None, 1e-7) * 3.1415
        logit_t = F.layer_norm(logit_t, torch.Size((100,)), None, None, 1e-7) * 3.1415
        pred_feat_s = F.layer_norm(pred_feat_s, torch.Size((100,)), None, None, 1e-7) * 3.1415
        # cls + kl div
        loss_kd = self.crit2(pred_feat_s, logit_s.detach()) + self.crit2(logit_s, pred_feat_s.detach())
        loss_kd += self.crit1(pred_feat_s, label) + self.crit3(pred_feat_s, logit_t.detach())
        return loss_kd

