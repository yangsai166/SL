"""
the general training framework
"""

from __future__ import print_function

import os
import argparse
import socket
import time
import sys
from tqdm import tqdm
import mkl

import torch
import torch.optim as optim
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.utils.data import DataLoader
import torch.nn.functional as F
from torch.optim.lr_scheduler import MultiStepLR
from models import model_pool
from models.util import create_model, get_teacher_name

from distill.util import Embed
from distill.criterion import DistillKL, NCELoss, Attention, HintLoss


from dataset.mini_imagenet import ImageNet, MetaImageNet

from dataset.cifar import CIFAR100, MetaCIFAR100
from dataset.transform_cfg import transforms_options, transforms_list

from util import adjust_learning_rate, accuracy, AverageMeter
from eval.meta_eval import meta_test, meta_test_tune
from eval.cls_eval import validate

from models.resnet import resnet12
import numpy as np
from util import Logger

from dataloader import get_dataloaders
import copy

"""Deep Mutual Learning,CVPR2018
    """

os.environ["CUDA_VISIBLE_DEVICES"] = '0'





def parse_option():
    parser = argparse.ArgumentParser('argument for training')

    parser.add_argument('--eval_freq', type=int, default=10, help='meta-eval frequency')
    parser.add_argument('--print_freq', type=int, default=100, help='print frequency')
    parser.add_argument('--tb_freq', type=int, default=500, help='tb frequency')
    parser.add_argument('--save_freq', type=int, default=10, help='save frequency')
    parser.add_argument('--batch_size', type=int, default=64, help='batch_size')
    parser.add_argument('--num_workers', type=int, default=8, help='num of workers to use')
    parser.add_argument('--epochs', type=int, default=100, help='number of training epochs')

    # optimization
    parser.add_argument('--learning_rate', type=float, default=0.05, help='learning rate')
    parser.add_argument('--lr_decay_epochs', type=str, default='60,80', help='where to decay lr, can be a list')
    parser.add_argument('--lr_decay_rate', type=float, default=0.1, help='decay rate for learning rate')
    parser.add_argument('--weight_decay', type=float, default=5e-4, help='weight decay')
    parser.add_argument('--momentum', type=float, default=0.9, help='momentum')

    # dataset and model
    parser.add_argument('--model_names', type=str, nargs='+', default=['convnet4', 'convnet4'])
    parser.add_argument('--model_s', type=str, default='convnet4', choices=model_pool)
    parser.add_argument('--dataset', type=str, default='miniImageNet', choices=['miniImageNet', 'CIFAR-FS', 'FC100','CUB_200_2011'])
    parser.add_argument('--simclr', type=bool, default=False, help='use simple contrastive learning representation')
    parser.add_argument('--ssl', type=bool, default=True, help='use self supervised learning')
    parser.add_argument('--transform', type=str, default='A', choices=transforms_list)
    # distillation
    parser.add_argument('--distill', type=str, default='kd', choices=['kd', 'contrast', 'hint', 'attention'])
    parser.add_argument('--trial', type=str, default='1', help='trial id')

    parser.add_argument('-r', '--gamma', type=float, default=1, help='weight for classification')
    parser.add_argument('-a', '--alpha', type=float, default=1, help='weight balance for KD')
    parser.add_argument('-b', '--beta', type=float, default=0, help='weight balance for feature losses')
    parser.add_argument('-t', '--theta', type=float, default=0, help='weight balance for other losses')
    parser.add_argument('--n_cluster', default=5, type=int, help='number of cluster')

    # KL distillation
    parser.add_argument('--kd_T', type=float, default=16, help='temperature for KD distillation')


    # cosine annealing
    parser.add_argument('--cosine', action='store_true', help='using cosine annealing')

    # specify folder
    parser.add_argument('--model_path', type=str, default='save/distillation/', help='path to save model')
    parser.add_argument('--data_root', type=str, default='/Datasets/',
                        help='path to data root')

    # setting for meta-learning
    parser.add_argument('--n_test_runs', type=int, default=600, metavar='N',
                        help='Number of test runs')
    parser.add_argument('--n_ways', type=int, default=5, metavar='N',
                        help='Number of classes for doing each classification run')
    parser.add_argument('--n_shots', type=int, default=1, metavar='N',
                        help='Number of shots in test')
    parser.add_argument('--n_queries', type=int, default=15, metavar='N',
                        help='Number of query in test')
    parser.add_argument('--n_aug_support_samples', default=5, type=int,
                        help='The number of augmented samples for each meta test sample')
    parser.add_argument('--test_batch_size', type=int, default=1, metavar='test_batch_size',
                        help='Size of test batch)')

    opt = parser.parse_args()

    if opt.dataset == 'CIFAR-FS' or opt.dataset == 'FC100':
        opt.transform = 'D'


    opt.use_trainval = False


    # set the path according to the environment
    if not opt.model_path:
        opt.model_path = './models_distilled'
    if not opt.data_root:
        opt.data_root = './data/{}'.format(opt.dataset)
    else:
        opt.data_root = '{}/{}'.format(opt.data_root, opt.dataset)
    opt.data_aug = True
    iterations = opt.lr_decay_epochs.split(',')
    opt.lr_decay_epochs = list([])
    for it in iterations:
        opt.lr_decay_epochs.append(int(it))

    opt.model_name = 'S:{}'.format(opt.model_s)

    if opt.cosine:
        opt.model_name = '{}_cosine'.format(opt.model_name)

    opt.model_name = '{}_{}'.format(opt.model_name, opt.trial)
    opt.save_folder = os.path.join(opt.model_path, opt.model_name)
    if not os.path.isdir(opt.save_folder):
        os.makedirs(opt.save_folder)
    # extras
    opt.fresh_start = True

    return opt

def load_teacher(model_path, model_name, n_cls, dataset='miniImageNet'):
    """load the  model"""
    print('==> loading model {}'.format(model_name))
    model = create_model(model_name, n_cls, dataset)
    model.load_state_dict(torch.load(model_path)['model'])
    print('==> done')
    return model

def main():
    best_acc = 0

    opt = parse_option()

    # dataloader
    train_loader, val_loader, meta_testloader, meta_valloader, n_cls = get_dataloaders(opt)
    nets, optimizers, schs = [], [], []
    for name in opt.model_names:
        model = create_model(opt.model_s, n_cls, opt.dataset)
        optimizer = optim.SGD(model.parameters(), lr=opt.learning_rate, momentum=opt.momentum, weight_decay=opt.weight_decay)
        scheduler = MultiStepLR(optimizer, opt.lr_decay_epochs)
        nets.append(model)
        optimizers.append(optimizer)
        schs.append(scheduler)

    criterion_cls = nn.CrossEntropyLoss()
    criterion_div = DistillKL(opt.kd_T)
    criterion_kd = DistillKL(opt.kd_T)
    if torch.cuda.is_available():
        for net in nets:
            net.cuda()
        criterion_cls = criterion_cls.cuda()
        criterion_div = criterion_div.cuda()
        criterion_kd = criterion_kd.cuda()
        cudnn.benchmark = True

    meta_test_acc = np.zeros(len(nets))
    best_test_acc = np.zeros(len(nets))
    meta_val_acc = 0
    # routine: supervised model distillation
    for epoch in range(1, opt.epochs + 1):
        for net_idx, optimizer in enumerate(optimizers):
            adjust_learning_rate(epoch, opt, optimizer)
        print("==> training...")

        time1 = time.time()
        train_loss = train(epoch, train_loader, nets, optimizers, criterion_cls, criterion_div, criterion_kd, opt)
        time2 = time.time()
        print('epoch {}, total time {:.2f}'.format(epoch, time2 - time1))

        for net_idx, net in enumerate(nets):
            meta_test_acc1, meta_test_std1 = meta_test(net, meta_testloader, use_logit=True)
            print('Meta Test Acc: {:.4f}, Meta Test std: {:.4f}'.format(meta_test_acc1, meta_test_std1))
            if meta_test_acc1 > best_test_acc[net_idx]:
               best_test_acc[net_idx] = meta_test_acc1
            print('==> Saving at epoch{}...'.format(epoch))
            state = {
                'epoch': epoch,
                'model': net.state_dict(),
            }
            save_file = os.path.join(opt.save_folder, f'net{net_idx}ep.pth')
            torch.save(state, save_file)

def train(epoch, train_loader, nets, optimizers, criterion_cls, criterion_div, criterion_kd, opt):
    for net in nets:
        net.train()
    train_loss, total = np.zeros(len(nets)), 0
    with tqdm(train_loader, total=len(train_loader)) as pbar:
        for idx, data in enumerate(pbar):

            inputs, targets, _ = data

            inputs = inputs.float()
            if torch.cuda.is_available():
                inputs = inputs.cuda()
                targets = targets.cuda()

            batch_size = inputs.size()[0]
            x = inputs
            inputs_all = x

            # ===================forward=====================
            out_list = []
            for net_idx, net in enumerate(nets):
                feat_s_all,(logit_s_all,_)  = net(inputs_all, rot=True)# [b, num_classes]
                out_list.append(logit_s_all)
            for net_idx, net in enumerate(nets):
                ce_loss = criterion_cls(out_list[net_idx], targets)
                KLD_loss = 0
                for l in range(len(nets)):
                    if l != net_idx:
                        KLD_loss += criterion_div(out_list[net_idx], out_list[l].detach())

                loss = ce_loss + KLD_loss / (len(nets) - 1)

                optimizers[net_idx].zero_grad()
                loss.backward()
                optimizers[net_idx].step()

                train_loss[net_idx] += loss.item()
                if net_idx == 0:
                    total += targets.size(0)

        return list(np.round(train_loss / total, 4))



if __name__ == '__main__':
    main()
