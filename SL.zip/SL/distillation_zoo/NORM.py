import torch
import torch.nn as nn
import torch.nn.functional as F

"""NORM: KNOWLEDGE DISTILLATION VIA N-TO-ONE REPRESENTATION MATCHING
    code: https://github.com/OSVAI/NORM."""
def conv1x1(in_channels, out_channels, stride=1):
    return nn.Conv2d(
        in_channels, out_channels,
        kernel_size=1, padding=0,
        bias=False, stride=stride)
class NORMLoss(nn.Module):
    def __init__(self):
        super(NORMLoss, self).__init__()
        self.co_sponge= 4

    def Norm_loss(self, feat_t, feat_s):

        loss_norm = 0

        for f_t, f_s in zip(feat_t[1:-2], feat_s[1:-2]):  # reversely compute to avoid muti-stage training problem

            f_t1 = f_t
            f_s1 = f_s
            projector=conv1x1(f_t1.shape[1],f_s1.shape[1],stride=1).cuda()
            f_t1 = projector(f_t1)

            #pool_size = f_s.shape[2] // f_t.shape[2]



            f_s1 = F.max_pool2d(f_s1, f_s1.shape[2], f_s1.shape[2])

            f_t1 = F.max_pool2d(f_t1, f_t1.shape[2], f_t1.shape[2])
            f_s1 = f_s1.view(f_s1.shape[0], -1)
            f_t1 = f_t1.view(f_t1.shape[0], -1)


                #f_t = torch.tile(f_t, [1, self.co_sponge, 1, 1])


            loss_norm += F.mse_loss(f_s1, f_t1.detach()) * self.co_sponge
        return  loss_norm